#!/bin/sh

cd bin
./MoneroVMiner
